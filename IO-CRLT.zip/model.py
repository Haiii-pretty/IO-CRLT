import torch
import torch.nn as nn
from torch.nn import BatchNorm2d, Conv2d, ModuleList
import torch.nn.functional as F
from transformer_model import Transformer
import torch.fft as fft
import math


def channel_shuffle(x, groups):
    batchsize, num_channels, height, width = x.data.size()
    channels_per_group = num_channels // groups
    x = x.view(batchsize, groups, channels_per_group, height, width)
    x = torch.transpose(x, 1, 2).contiguous()
    x = x.view(batchsize, -1, height, width)
    return x

class BandedFourierLayer(nn.Module):
    def __init__(self, in_channels, out_channels, band, num_bands, length):
        super().__init__()

        self.length = length
        self.total_freqs = (self.length // 2) + 1

        self.in_channels = in_channels
        self.out_channels = out_channels

        self.band = band  # zero indexed
        self.num_bands = num_bands

        self.num_freqs = self.total_freqs // self.num_bands + (self.total_freqs % self.num_bands if self.band == self.num_bands - 1 else 0)

        self.start = self.band * (self.total_freqs // self.num_bands)
        self.end = self.start + self.num_freqs


        # case: from other frequencies
        self.weight = nn.Parameter(torch.empty((self.num_freqs, self.num_freqs), dtype=torch.cfloat))
        self.bias = nn.Parameter(torch.empty((out_channels, self.num_freqs), dtype=torch.cfloat))
        self.reset_parameters()

    def forward(self, input):
        # input - b t d
        b, t, _ = input.shape
        input_fft = fft.rfft(input, dim=1).transpose(1,2)
        output_fft = self._forward(input_fft)
        output_fft = output_fft.transpose(1,2)
        # output_fft = torch.zeros(b, t // 2 + 1, self.out_channels, device=input.device, dtype=torch.cfloat)
        # output_fft[:, self.start:self.end] = self._forward(input_fft)
        return fft.irfft(output_fft, n=input.size(1), dim=1)

    def _forward(self, input):
        output = torch.einsum('bti,io->bto', input, self.weight)
        return output + self.bias

    def reset_parameters(self) -> None:
        nn.init.kaiming_uniform_(self.weight, a=math.sqrt(5))
        fan_in, _ = nn.init._calculate_fan_in_and_fan_out(self.weight)
        bound = 1 / math.sqrt(fan_in) if fan_in > 0 else 0
        nn.init.uniform_(self.bias, -bound, bound)

class MyTransformer(nn.Module):
    def __init__(self,hid_dim, layers, heads=8):
        super().__init__()
        self.heads = heads
        self.layers = layers
        self.hid_dim = hid_dim
        self.trans = Transformer(hid_dim, heads, layers)

    def forward(self, x, mask):
        x = self.trans(x, mask)
        return x

class SELayer(nn.Module):
    def __init__(self, channel, reduction=8):
        super(SELayer, self).__init__()
        self.avg_pool = nn.AdaptiveAvgPool1d(1)
        self.fc = nn.Sequential(
            nn.Linear(channel, channel // reduction, bias=False),
            nn.ReLU(inplace=True),
            nn.Linear(channel // reduction, channel, bias=False),
            nn.Sigmoid()
        )

    def forward(self, x):
        b, c, _ = x.size()
        y = self.avg_pool(x).view(b, c)
        y = self.fc(y).view(b, c, 1)
        return x * y.expand_as(x)


class Disentangler(nn.Module):

    def __init__(self,output_dims,component_dims,length):
        super(Disentangler,self).__init__()
        self.sfd = nn.ModuleList(
            [BandedFourierLayer(output_dims, component_dims, b, 1, length = length) for b in range(1)]
        )
        self.repr_dropout = nn.Dropout(p=0.3)

    def forward(self,x):

        season = []
        for mod in self.sfd:
            out = mod(x)  # b t d
            season.append(out)
        season = season[0]
        season = self.repr_dropout(season)

        return season


class ttnet(nn.Module):
    def __init__(self, dropout, supports, in_dim, out_dim, hid_dim, group, layers=4, cnn_layers=4,
                 tod_embedding_dim=8, dow_embedding_dim=8, steps_per_day=288, input_embedding_dim = 32,num_nodes = 207
                 ):
        super(ttnet, self).__init__()
        self.start_conv = Conv2d(in_channels=in_dim,
                                    out_channels=input_embedding_dim,
                                    kernel_size=(1, 1))
        self.cnn_layers = cnn_layers
        self.filter_convs = ModuleList()
        self.gate_convs = ModuleList()
        self.group=group
        D = [1, 2, 4, 8]
        additional_scope = 1
        receptive_field = 1
        for i in range(self.cnn_layers):
            self.filter_convs.append(Conv2d(hid_dim, hid_dim, (1, 2), dilation=D[i], groups=group))
            self.gate_convs.append(Conv2d(hid_dim, hid_dim, (1, 2), dilation=D[i], groups=group))
            receptive_field += additional_scope
            additional_scope *= 2
        self.receptive_field=receptive_field
        depth = list(range(self.cnn_layers))
        self.bn = ModuleList([BatchNorm2d(hid_dim) for _ in depth])


        mask0 = supports[0].detach()
        mask1 = supports[1].detach()
        mask = mask0 + mask1
        self.mask = mask == 0
        self.se=SELayer(hid_dim)
        self.se2=SELayer(hid_dim)
        self.input_embedding_dim = input_embedding_dim
        self.tod_embedding_dim = tod_embedding_dim
        self.dow_embedding_dim = dow_embedding_dim
        self.input_dim = 3
        if tod_embedding_dim > 0:
            self.tod_embedding = nn.Embedding(steps_per_day, tod_embedding_dim)
        if dow_embedding_dim > 0:
            self.dow_embedding = nn.Embedding(7, dow_embedding_dim)
        self.steps_per_day = steps_per_day
        self.input_proj = nn.Linear(in_dim, input_embedding_dim)
        self.hid_dim = 32 + tod_embedding_dim + dow_embedding_dim
        self.disentangler = Disentangler(num_nodes,num_nodes,self.hid_dim)




    def forward(self, input, tod, dow):

        if self.tod_embedding_dim > 0:
            tod = tod
        if self.dow_embedding_dim > 0:
            dow = dow
        x = self.start_conv(input)
        features = [x]
        if self.tod_embedding_dim > 0:
            tod_emb = self.tod_embedding(
                (tod * self.steps_per_day).long()
            )
            features.append(tod_emb.transpose(1,3))
        if self.dow_embedding_dim > 0:
            dow_emb = self.dow_embedding(
                dow.long()
            )  # (batch_size, in_steps, num_nodes, dow_embedding_dim)
            features.append(dow_emb.transpose(1,3))
        x = torch.cat(features, dim=1)
        in_len = x.size(3)
        if in_len < self.receptive_field:
            x = nn.functional.pad(x, (self.receptive_field - in_len, 0, 0, 0))

        skip = 0
        for i in range(self.cnn_layers):
            residual = x
            filter = torch.tanh(self.filter_convs[i](residual))
            gate = torch.sigmoid(self.gate_convs[i](residual))
            x = filter * gate
            if self.group !=1:
                x = channel_shuffle (x,self.group)
            try:
                skip += x[:, :, :, -1:]
            except:
                skip = 0
            if i == self.cnn_layers-1:
                break
            x = x + residual[:, :, :, -x.size(3):]
            x = self.bn[i](x)
        x = torch.squeeze(skip, dim=-1)
        x = self.se(x)
        all = x
        season = self.disentangler(x).transpose(1,2)
        x_residual = season
        # x = self.network(season,self.mask)
        # x += x_residual
        # x = F.relu(self.end_conv1(x))
        # x = self.end_conv2(x)
        return season,x_residual,all

class filter(nn.Module):
    def __init__(self, out_channels):
        super(filter,self).__init__()
        self.global_average_pool = nn.AdaptiveAvgPool1d(1)
        self.FC = nn.Sequential(
            nn.Linear(out_channels,out_channels),
            nn.BatchNorm1d(out_channels),
            nn.ReLU(),
            nn.Linear(out_channels,out_channels)
        )

    def forward(self,x):
        x = x.transpose(1,2)
        input = x
        x_abs = torch.abs(x)
        gap = self.global_average_pool(x)
        alpha = self.FC(gap.squeeze(-1))
        alpha = torch.sigmoid(alpha)
        threshold = torch.mul(gap,alpha.unsqueeze(-1))
        sub = x_abs - threshold
        zeros = sub - sub
        n_sub = torch.max(sub,zeros)
        x = torch.mul(torch.sign(input),n_sub)
        return x.transpose(1,2)




class IO_CRLT(nn.Module):
    def __init__(self, dropout, supports, in_dim, out_dim, hid_dim, group, layers=4, cnn_layers=4,
                 tod_embedding_dim=8, dow_embedding_dim=8, steps_per_day= 288, input_embedding_dim = 32,num_nodes = 207
                 ):
        super(IO_CRLT, self).__init__()
        self.wa_ex = ttnet(dropout,supports,in_dim,out_dim,hid_dim,group)
        self.sa_ex = ttnet(dropout, supports, in_dim, out_dim, hid_dim, group)
        self.end_conv1 = nn.Linear(hid_dim, hid_dim*4)
        self.end_conv2 = nn.Linear(hid_dim*4, out_dim)

        self.s_network = MyTransformer(hid_dim, layers=layers, heads=8)
        self.t_network = MyTransformer(hid_dim, layers=layers, heads=8)
        mask0 = supports[0].detach()
        mask1 = supports[1].detach()
        mask = mask0 + mask1
        self.mask = mask == 0
        self.se=SELayer(hid_dim)
        self.se2=SELayer(hid_dim)
        self.input_embedding_dim = input_embedding_dim
        self.tod_embedding_dim = tod_embedding_dim
        self.dow_embedding_dim = dow_embedding_dim
        self.input_dim = 3
        if tod_embedding_dim > 0:
            self.tod_embedding = nn.Embedding(steps_per_day, tod_embedding_dim)
        if dow_embedding_dim > 0:
            self.dow_embedding = nn.Embedding(7, dow_embedding_dim)
        self.steps_per_day = steps_per_day
        self.input_proj = nn.Linear(in_dim, input_embedding_dim)
        self.hid_dim = 32 + tod_embedding_dim + dow_embedding_dim
        self.disentangler = Disentangler(num_nodes,num_nodes,self.hid_dim)
        self.filter = filter(int(self.hid_dim))




    def forward(self, SA, WA, tod,dow,epoch=0):

        wa_season,wa_residual,all = self.wa_ex(WA,tod,dow)
        sa_season,sa_season,all = self.sa_ex(SA,tod,dow)
        season = self.s_network(wa_season,self.mask)
        trend = all.transpose(1,2) - season
        trend = self.filter(trend)
        smother = trend
        trend_residual = trend
        trend = self.t_network(trend,self.mask)
        season += wa_residual
        trend += trend_residual
        x = season + trend
        inner = x
        x = F.relu(self.end_conv1(x))
        x = self.end_conv2(x)
        return x.transpose(1, 2).unsqueeze(-1),wa_season,sa_season,smother,inner