import pandas as pd
import torch
import numpy as np
import argparse
import time
import util
from engine import trainer
from util import Granularity_jittering
from forecast_dataloader import ForecastDataset
from util import StandardScaler,series_decomp
from torch.utils.data import DataLoader
from statsmodels.tsa.api import acf
from early_stopping import EarlyStopping




parser = argparse.ArgumentParser()
parser.add_argument('--device',type=str,default='cuda:0',help='')
# parser.add_argument('--data',type=str,default='dataset/pems_bay',help='data path')
parser.add_argument('--data_path',type=str,default='dataset/METR-LA/METR_LA.h5',help='data path')
parser.add_argument('--adjdata',type=str,default='dataset/METR-LA/metr_la_adj_mx.pkl',help='adj data path')
parser.add_argument('--adjtype',type=str,default='doubletransition',help='adj type')
parser.add_argument('--seq_length',type=int,default=12,help='')
parser.add_argument('--nhid',type=int,default=48,help='')
parser.add_argument('--in_dim',type=int,default=3,help='inputs dimension')
parser.add_argument('--batch_size',type=int,default=32,help='batch size')
parser.add_argument('--learning_rate',type=float,default=0.002,help='learning rate')
parser.add_argument('--dropout',type=float,default=0.1,help='dropout rate')
parser.add_argument('--group',type=float,default=4,help='g^t number')
parser.add_argument('--weight_decay',type=float,default=0.0001,help='weight decay rate')
parser.add_argument('--epochs',type=int,default=100,help='')
parser.add_argument('--print_every',type=int,default=50,help='')
parser.add_argument('--save',type=str,default='logs/',help='save path')
parser.add_argument('--expid',type=int,default=1,help='experiment id')
parser.add_argument('--checkpoint',type=str,default='/logs/best.pth')
parser.add_argument('--num_workers',type=str,default='/logs/best.pth')
parser.add_argument('--patience',type=int,default=15)

args = parser.parse_args()

def main():
    device = torch.device(args.device)
    adj_mx = util.load_adj(args.adjdata, args.adjtype)
    try:
        data = pd.read_hdf(args.data_path, index_col=[0])
    except:
        data = pd.read_csv(args.data_path,index_col=[0])
    # split data
    train_ratio = 0.7
    valid_ratio = 0.1
    train_data = data[:int(train_ratio * len(data))]
    valid_data = data[int(train_ratio * len(data)):int((train_ratio + valid_ratio) * len(data))]
    test_data = data[int((train_ratio + valid_ratio) * len(data)):]
    scaler = StandardScaler(mean=train_data.values.mean(),std=train_data.values.std())
    train_set = ForecastDataset(scaler,train_data, window_size=args.seq_length, horizon=args.seq_length)
    valid_set = ForecastDataset(scaler,valid_data, window_size=args.seq_length, horizon=args.seq_length)
    test_set = ForecastDataset(scaler,test_data, window_size=args.seq_length, horizon=args.seq_length)
    train_loader = DataLoader(train_set, batch_size=args.batch_size, drop_last=False, shuffle=True, num_workers=0)
    val_loader = DataLoader(valid_set, batch_size=args.batch_size, drop_last=False, shuffle=False, num_workers=0)
    test_loader = DataLoader(test_set, batch_size=args.batch_size, drop_last=False, shuffle=False, num_workers=0)
    x = torch.from_numpy(train_data.values).numpy()
    acf_values = []
    for i_ch in range(x.shape[-1]):
        acf_values.append(acf(x[..., i_ch], nlags=len(x)))
    acf_values = np.stack(acf_values, axis=0).mean(axis=0)
    supports = [torch.tensor(i).to(device) for i in adj_mx]
    engine = trainer(acf_values,args.batch_size,scaler, args.in_dim, args.seq_length, args.nhid , args.dropout, args.learning_rate, args.weight_decay, args.device, supports, args.group)
    model = engine.model
    model.to(device)
    early_stop = EarlyStopping(patience=args.patience,verbose=True)
    print('model load successfully')
    jitter = Granularity_jittering(device)
    print("start training...",flush=True)
    his_loss =[]
    hiss_loss = []
    val_time = []
    train_time = []
    epoch = -1
    for i in range(1, args.epochs + 1):
        epoch += 1
        train_loss = []
        train_mape = []
        train_rmse = []
        t1 = time.time()
        for iter, (timeidx,x, y) in enumerate(train_loader):
            trainx = torch.Tensor(x).to(device)
            tod = trainx[..., 1]
            dow = trainx[..., 2]
            SA = jitter.strong_transform(trainx)
            SA = torch.Tensor(SA).to(device)
            SA = SA.transpose(1, 3)
            WA = jitter.weak_transform(trainx)
            WA = torch.Tensor(WA).to(device)
            WA = WA.transpose(1, 3)
            trainy = torch.Tensor(y).to(device)
            metrics = engine.train(timeidx,SA, WA,tod,dow,trainy,epoch)
            train_loss.append(metrics[0])
            train_mape.append(metrics[1])
            train_rmse.append(metrics[2])
            if iter % args.print_every == 0:
                log = 'Iter: {:03d}, Train Loss: {:.4f}, Train MAPE: {:.4f}, Train RMSE: {:.4f}'
                print(log.format(iter, train_loss[-1], train_mape[-1], train_rmse[-1]),flush=True)
        t2 = time.time()
        train_time.append(t2-t1)

        #validation
        valid_loss = []
        valid_mape = []
        valid_rmse = []
        s1 = time.time()
        for iter, (timeidx, x, y) in enumerate(val_loader):
            valx = torch.Tensor(x).to(device)
            tod = valx[..., 1]
            dow = valx[..., 2]
            valx = valx.transpose(1, 3)
            valy = torch.Tensor(y).to(device)
            metrics = engine.eval(valx, valx,tod,dow,valy)
            valid_loss.append(metrics[0])
            valid_mape.append(metrics[1])
            valid_rmse.append(metrics[2])
        s2 = time.time()
        log = 'Epoch: {:03d}, Inference Time: {:.4f} secs'
        print(log.format(i,(s2-s1)))
        val_time.append(s2-s1)
        mtrain_loss = np.mean(train_loss)
        mtrain_mape = np.mean(train_mape)
        mtrain_rmse = np.mean(train_rmse)
        mvalid_loss = np.mean(valid_loss)
        mvalid_mape = np.mean(valid_mape)
        mvalid_rmse = np.mean(valid_rmse)

        #lr decay
        engine.scheduler.step()

        his_loss.append(mvalid_loss)
        torch.save(engine.model.state_dict(),
                   args.save + "_epoch_" + str(i) + "_" + str(round(mvalid_loss, 2)) + ".pth")
        early_stop(mtrain_loss,engine.model)
        log = 'Epoch: {:03d}\nTrain Loss: {:.4f}, Train MAPE: {:.4f}, Train RMSE: {:.4f}\nValid Loss: {:.4f}, Valid MAPE: {:.4f}, Valid RMSE: {:.4f}\nTraining Time: {:.4f}/epoch'
        print(log.format(i, mtrain_loss, mtrain_mape, mtrain_rmse, mvalid_loss, mvalid_mape, mvalid_rmse, (t2 - t1)),flush=True)
        if early_stop.early_stop:
            print('Early stopping')
            break
    print("Average Training Time: {:.4f} secs/epoch".format(np.mean(train_time)))
    print("Average Inference Time: {:.4f} secs".format(np.mean(val_time)))

    #testing
    bestid = np.argmin(his_loss)
    engine.model.load_state_dict(torch.load(args.save+"_epoch_"+str(bestid+1)+"_"+str(round(his_loss[bestid],2))+".pth",weights_only=True))

    outputs = []
    realy = []
    start = time.time()
    for iter, (timeidx,x, y) in enumerate(test_loader):
        testx = torch.Tensor(x).to(device)
        tod = testx[..., 1]
        dow = testx[..., 2]
        testx = testx.transpose(1,3)
        testy = torch.Tensor(y).to(device)
        with torch.no_grad():
            preds,_,_,_,_ = engine.model(testx,testx,tod,dow)
            preds = preds.transpose(1,3).squeeze(1)
        outputs.append(preds)
        realy.append(testy.transpose(1,2))
    end = time.time()
    print(f'test Inference time:{end-start}')
    yhat = torch.cat(outputs,dim=0)
    yhat = scaler.inverse_transform(yhat)
    realy = torch.cat(realy,dim=0)

    print("Training finished")
    print("The valid loss on model is", str(round(his_loss[bestid],4)))

    amae = []
    amape = []
    armse = []
    print(yhat.shape, realy.shape)
    for i in range(12):
        pred = yhat[...,i]
        real = realy[...,i]
        metrics = util.metric(pred,real)
        log = 'Evaluate model on test data for horizon {:d}, Test MAE: {:.4f}, Test MAPE: {:.4f}, Test RMSE: {:.4f}'
        print(log.format(i+1, metrics[0], metrics[1], metrics[2]))
        amae.append(metrics[0])
        amape.append(metrics[1])
        armse.append(metrics[2])

    log = 'On average over 12 horizons, Test MAE: {:.4f}, Test MAPE: {:.4f}, Test RMSE: {:.4f}'
    print(log.format(*util.metric(yhat,realy)))
    torch.save(engine.model.state_dict(), args.save+"_exp"+str(args.expid)+"_best_"+str(round(his_loss[bestid],2))+".pth")




if __name__ == "__main__":
    t1 = time.time()
    main()
    t2 = time.time()
    print("Total time spent: {:.4f}".format(t2-t1))
