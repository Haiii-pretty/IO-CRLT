import pickle
import numpy as np
import os
import scipy.sparse as sp
import torch
from scipy.sparse import linalg
import csv
import copy
import torch
import torch.nn as nn
class DataLoader(object):
    def __init__(self, xs, ys, batch_size, pad_with_last_sample=True):

        self.batch_size = batch_size
        self.current_ind = 0
        if pad_with_last_sample:
            num_padding = (batch_size - (len(xs) % batch_size)) % batch_size
            x_padding = np.repeat(xs[-1:], num_padding, axis=0)
            y_padding = np.repeat(ys[-1:], num_padding, axis=0)
            xs = np.concatenate([xs, x_padding], axis=0)
            ys = np.concatenate([ys, y_padding], axis=0)
        self.size = len(xs)
        self.num_batch = int(self.size // self.batch_size)
        self.xs = xs
        self.ys = ys

    def shuffle(self):
        permutation = np.random.permutation(self.size)
        xs, ys = self.xs[permutation], self.ys[permutation]
        self.xs = xs
        self.ys = ys

    def get_iterator(self):
        self.current_ind = 0

        def _wrapper():
            while self.current_ind < self.num_batch:
                start_ind = self.batch_size * self.current_ind
                end_ind = min(self.size, self.batch_size * (self.current_ind + 1))
                x_i = self.xs[start_ind: end_ind, ...]
                y_i = self.ys[start_ind: end_ind, ...]
                yield (self.current_ind,x_i, y_i)
                self.current_ind += 1

        return _wrapper()

class StandardScaler():
    def __init__(self, mean, std):
        self.mean = mean
        self.std = std

    def transform(self, data):
        return (data - self.mean) / self.std

    def inverse_transform(self, data):
        return (data * self.std) + self.mean



def sym_adj(adj):
    adj = sp.coo_matrix(adj)
    rowsum = np.array(adj.sum(1))
    d_inv_sqrt = np.power(rowsum, -0.5).flatten()
    d_inv_sqrt[np.isinf(d_inv_sqrt)] = 0.
    d_mat_inv_sqrt = sp.diags(d_inv_sqrt)
    return adj.dot(d_mat_inv_sqrt).transpose().dot(d_mat_inv_sqrt).astype(np.float32).todense()

def asym_adj(adj):
    adj = sp.coo_matrix(adj)
    rowsum = np.array(adj.sum(1)).flatten()
    d_inv = np.power(rowsum, -1).flatten()
    d_inv[np.isinf(d_inv)] = 0.
    d_mat= sp.diags(d_inv)
    return d_mat.dot(adj).astype(np.float32).todense()

def calculate_normalized_laplacian(adj):
    adj = sp.coo_matrix(adj)
    d = np.array(adj.sum(1))
    d_inv_sqrt = np.power(d, -0.5).flatten()
    d_inv_sqrt[np.isinf(d_inv_sqrt)] = 0.
    d_mat_inv_sqrt = sp.diags(d_inv_sqrt)
    normalized_laplacian = sp.eye(adj.shape[0]) - adj.dot(d_mat_inv_sqrt).transpose().dot(d_mat_inv_sqrt).tocoo()
    return normalized_laplacian

def calculate_scaled_laplacian(adj_mx, lambda_max=2, undirected=True):
    if undirected:
        adj_mx = np.maximum.reduce([adj_mx, adj_mx.T])
    L = calculate_normalized_laplacian(adj_mx)
    if lambda_max is None:
        lambda_max, _ = linalg.eigsh(L, 1, which='LM')
        lambda_max = lambda_max[0]
    L = sp.csr_matrix(L)
    M, _ = L.shape
    I = sp.identity(M, format='csr', dtype=L.dtype)
    L = (2 / lambda_max * L) - I
    return L.astype(np.float32).todense()

def load_pickle(pickle_file):
    try:
        with open(pickle_file, 'rb') as f:
            pickle_data = pickle.load(f)
    except UnicodeDecodeError as e:
        with open(pickle_file, 'rb') as f:
            pickle_data = pickle.load(f, encoding='latin1')
    except Exception as e:
        print('Unable to load data ', pickle_file, ':', e)
        raise
    return pickle_data

def load_adj(pkl_filename, adjtype):
    try:
        _,_,adj_mx = load_pickle(pkl_filename)
    except:
        adj_mx = load_pickle(pkl_filename)
    if adjtype == "scalap":
        adj = [calculate_scaled_laplacian(adj_mx)]
    elif adjtype == "normlap":
        adj = [calculate_normalized_laplacian(adj_mx).astype(np.float32).todense()]
    elif adjtype == "symnadj":
        adj = [sym_adj(adj_mx)]
    elif adjtype == "transition":
        adj = [asym_adj(adj_mx)]
    elif adjtype == "doubletransition":
        adj = [asym_adj(adj_mx), asym_adj(np.transpose(adj_mx))]
    elif adjtype == "identity":
        adj = [np.diag(np.ones(adj_mx.shape[0])).astype(np.float32)]
    else:
        error = 0
        assert error, "adj type not defined"
    return adj


def load_dataset(dataset_dir, batch_size, valid_batch_size= None, test_batch_size=None):
    data = {}
    for category in ['train', 'val', 'test']:
        cat_data = np.load(os.path.join(dataset_dir, category + '.npz'))
        data['x_' + category] = cat_data['x']
        data['y_' + category] = cat_data['y']


    scaler = StandardScaler(mean=data['x_train'][..., 0].mean(), std=data['x_train'][..., 0].std())
    # Data format
    for category in ['train', 'val', 'test']:
        data['x_' + category][..., 0] = scaler.transform(data['x_' + category][..., 0])
    data['train_loader'] = DataLoader(data['x_train'], data['y_train'], batch_size)
    data['val_loader'] = DataLoader(data['x_val'], data['y_val'], valid_batch_size)
    data['test_loader'] = DataLoader(data['x_test'], data['y_test'], test_batch_size)
    data['scaler'] = scaler
    return data

def masked_mse(preds, labels, null_val=np.nan):
    if np.isnan(null_val):
        mask = ~torch.isnan(labels)
    else:
        mask = (labels!=null_val)
    mask = mask.float()
    mask /= torch.mean((mask))
    mask = torch.where(torch.isnan(mask), torch.zeros_like(mask), mask)
    loss = (preds-labels)**2
    loss = loss * mask
    loss = torch.where(torch.isnan(loss), torch.zeros_like(loss), loss)
    return torch.mean(loss)

def masked_rmse(preds, labels, null_val=np.nan):
    return torch.sqrt(masked_mse(preds=preds, labels=labels, null_val=null_val))


def masked_mae(preds, labels, null_val=np.nan):
    if np.isnan(null_val):
        mask = ~torch.isnan(labels)
    else:
        mask = (labels!=null_val)
    mask = mask.float()
    mask /=  torch.mean((mask))
    mask = torch.where(torch.isnan(mask), torch.zeros_like(mask), mask)
    loss = torch.abs(preds-labels)
    loss = loss * mask
    loss = torch.where(torch.isnan(loss), torch.zeros_like(loss), loss)
    return torch.mean(loss)



def masked_mape(preds, labels, null_val=np.nan):
    if np.isnan(null_val):
        mask = ~torch.isnan(labels)
    else:
        mask = (labels!=null_val)
    mask = mask.float()
    mask /=  torch.mean((mask))
    mask = torch.where(torch.isnan(mask), torch.zeros_like(mask), mask)
    loss = torch.abs(preds-labels)/labels
    loss = loss * mask
    loss = torch.where(torch.isnan(loss), torch.zeros_like(loss), loss)
    return torch.mean(loss)


def metric(pred, real):
    mae = masked_mae(pred,real,0.0).item()
    mape = masked_mape(pred,real,0.0).item()
    rmse = masked_rmse(pred,real,0.0).item()
    return mae,mape,rmse

def generate_data(graph_signal_matrix_name, batch_size, test_batch_size=None, transformer=None):

    origin_data = np.load(graph_signal_matrix_name)  # shape=[17856, 170, 3]
    keys = origin_data.keys()
    if 'train' in keys and 'val' in keys and 'test' in keys:
        data = generate_from_train_val_test(origin_data, transformer)

    elif 'data' in keys:
        length = origin_data['data'].shape[0]
        data = generate_from_data(origin_data, length, transformer)

    else:
        raise KeyError("neither data nor train, val, test is in the data")

    scalar = StandardScaler(mean=data['x_train'][..., 0].mean(), std=data['x_train'][..., 0].std())
    for category in ['train', 'val', 'test']:
        data['x_' + category][..., 0] = scalar.transform(data['x_' + category][..., 0])

    train_len = len(data['x_train'])
    permutation = np.random.permutation(train_len)
    data['x_train_1'] = data['x_train'][permutation][:int(train_len / 2)]
    data['y_train_1'] = data['y_train'][permutation][:int(train_len / 2)]
    data['x_train_2'] = data['x_train'][permutation][int(train_len / 2):]
    data['y_train_2'] = data['y_train'][permutation][int(train_len / 2):]
    data['x_train_3'] = copy.deepcopy(data['x_train_2'])
    data['y_train_3'] = copy.deepcopy(data['y_train_2'])
    data['train_loader_1'] = DataLoader(data['x_train_1'], data['y_train_1'], batch_size)
    data['train_loader_2'] = DataLoader(data['x_train_2'], data['y_train_2'], batch_size)
    data['train_loader_3'] = DataLoader(data['x_train_3'], data['y_train_3'], batch_size)

    data['train_loader'] = DataLoader(data['x_train'], data['y_train'], batch_size)
    data['val_loader'] = DataLoader(data['x_val'], data['y_val'], test_batch_size)
    data['test_loader'] = DataLoader(data['x_test'], data['y_test'], test_batch_size)
    data['scaler'] = scalar

    return data


def generate_from_train_val_test(origin_data, transformer):
    data = {}
    for key in ('train', 'val', 'test'):
        x, y = generate_seq(origin_data[key], 12, 12)
        data['x_' + key] = x.astype('float32')
        data['y_' + key] = y.astype('float32')


    return data


def generate_from_data(origin_data, length, transformer):
    data = {}
    train_line, val_line = int(length * 0.6), int(length * 0.8)
    for key, line1, line2 in (('train', 0, train_line),
                              ('val', train_line, val_line),
                              ('test', val_line, length)):

        x, y = generate_seq(origin_data['data'][line1: line2], 12, 12)
        data['x_' + key] = x.astype('float32')
        data['y_' + key] = y.astype('float32')
    return data


def generate_seq(data, train_length, pred_length):
    seq = np.concatenate([np.expand_dims(
        data[i: i + train_length + pred_length], 0)
        for i in range(data.shape[0] - train_length - pred_length + 1)],
        axis=0)[:, :, :, 0: 1]
    return np.split(seq, 2, axis=1)



class Granularity_jittering():

    def __init__(self,
                 device,
                 sigma = 0.2):
        self.device = device
        self.sigma= sigma

    def strong_transform(self,x):
        return self.random_time_step_mask(self.jitter(x))

    def weak_transform(self,x):
        return self.jitter(x)

    def shift(self,x):
        x = x.transpose(2,-1)
        shif = (torch.randn(x.size(-1)) * self.sigma).to(self.device)
        return (x + shif).transpose(2,-1)

    def jitter(self,x):
        noise = (torch.randn_like(x)*self.sigma).to(self.device)
        noise = torch.Tensor(noise)
        return x + noise

    def random_time_step_mask(self,tensor, mask_probability=0.2):
        # 获取张量的形状
        batch_size, channels, nodes, sequence_length = tensor.shape

        # 创建掩码矩阵，每个时间步的元素有10%的概率被掩码
        mask = torch.rand(batch_size, channels, nodes, sequence_length) < mask_probability

        # 将掩码位置的元素设为0
        tensor[mask] = 0

        return tensor

    def random_temporal_mask(self, tensor, mask_ratio=0.25, fill_value=0):
        """
        时间序列连续块掩码函数（修复版本）
        Args:
            tensor (torch.Tensor): 输入张量 (batch, sequence, nodes, channels)
            mask_ratio (float): 目标掩码比例（默认0.2）
            fill_value (float): 掩码填充值（默认0）
        Returns:
            torch.Tensor: 掩码后的张量
        """
        batch_size, seq_len, nodes, channels = tensor.shape

        # 计算每个样本的掩码步数（动态调整保持平均比例）
        mask_steps_float = seq_len * mask_ratio
        base_steps = int(mask_steps_float)
        fractional = mask_steps_float - base_steps

        # 生成随机步数调整（使平均步数接近目标值）
        rand_vals = torch.rand(batch_size, device=self.device)
        mask_steps = base_steps + (rand_vals < fractional).long()

        # 处理极端情况（保证掩码长度不超过序列长度）
        mask_steps = torch.clamp(mask_steps, max=seq_len)

        # 计算有效起始位置范围
        max_start = torch.clamp(seq_len - mask_steps, min=0)

        # 生成随机起始位置（修复关键错误）
        rand_ratio = torch.rand(batch_size, device=self.device)
        starts = (rand_ratio * (max_start.float() + 1e-6)).long()  # 避免除零

        # 创建时间轴坐标矩阵
        time_axis = torch.arange(seq_len, device=self.device)[None, :]  # 添加批次维度

        # 生成掩码区域
        mask = (time_axis >= starts[:, None]) & (time_axis < (starts + mask_steps)[:, None])

        # 扩展掩码维度并应用
        mask = mask.view(batch_size, seq_len, 1, 1).expand_as(tensor)
        return tensor.masked_fill(mask, fill_value)


class moving_avg(nn.Module):
    """
    Moving average block to highlight the trend of time series
    """
    def __init__(self, kernel_size, stride):
        super(moving_avg, self).__init__()
        self.kernel_size = kernel_size
        self.avg = nn.AvgPool1d(kernel_size=kernel_size, stride=stride, padding=0)

    def forward(self, x):
        # padding on the both ends of time series
        front = x[:, 0:1, :].repeat(1, (self.kernel_size - 1) // 2, 1)
        end = x[:, -1:, :].repeat(1, (self.kernel_size - 1) // 2, 1)
        x = torch.cat([front, x, end], dim=1)
        x = self.avg(x.permute(0, 2, 1))
        x = x.permute(0, 2, 1)
        return x


class series_decomp(nn.Module):
    """
    Series decomposition block
    """
    def __init__(self, kernel_size):
        super(series_decomp, self).__init__()
        self.moving_avg = moving_avg(kernel_size, stride=1)

    def forward(self, x):
        moving_mean = self.moving_avg(x)
        res = x - moving_mean
        return res, moving_mean


