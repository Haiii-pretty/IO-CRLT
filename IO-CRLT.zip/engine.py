import torch.optim as optim
from model import *
import util
import torch
from statsmodels.tsa.api import acf
import numpy as np
from losses import AutoCon

class trainer():
    def __init__(self,acf_values, batch_size,scaler, in_dim, seq_length, nhid, dropout, lrate, wdecay, device, supports, group, lr_decay_rate=.98):
        self.model = IO_CRLT(dropout=dropout, supports=supports, in_dim=in_dim, out_dim=seq_length, hid_dim=nhid,
                           group=group)
        self.model.to(device)
        self.optimizer = optim.Adam(self.model.parameters(), lr=lrate, weight_decay=wdecay)
        self.loss = util.masked_mae
        self.scaler = scaler
        self.clip = 3
        self.scheduler = optim.lr_scheduler.LambdaLR(
            self.optimizer, lr_lambda=lambda epoch: lr_decay_rate ** epoch)
        self.alpha = 0.004
        self.get_inner_loss = self.init_inner_loss(batch_size,nhid)
        self.acf_values = acf_values

    def init_inner_loss(self,batch_size,seq_len):
        loss = AutoCon(batch_size, seq_len, temperature=1.0, base_temperature=1.0)
        return loss

    def convert_coeff(self, x, eps=1e-6):  # x.real.shape->(8,1501,160)
        amp = torch.sqrt((x.real + eps).pow(2) + (x.imag + eps).pow(2))  # amp.shape(8,1501,160)
        phase = torch.atan2(x.imag, x.real + eps)  # phase.shape->(8,1501,160)
        return amp, phase

    def outer_loss(self, z1, z2):
        B, T = z1.size(0), z1.size(1)
        z = torch.cat([z1, z2], dim=0)  # 2B x T x C
        z = z.transpose(0, 1)  # T x 2B x C
        sim = torch.matmul(z, z.transpose(1, 2))  # T x 2B x 2B
        logits = torch.tril(sim, diagonal=-1)[:, :, :-1]  # T x 2B x (2B-1)
        logits += torch.triu(sim, diagonal=1)[:, :, 1:]
        logits = -F.log_softmax(logits, dim=-1)

        i = torch.arange(B, device=z1.device)
        loss = (logits[:, i, B + i - 1].mean() + logits[:, B + i, i].mean()) / 2
        return loss

    def inner_loss(self,timeindex,inner_trend):

        acf_values = self.acf_values
        features = F.normalize(inner_trend.transpose(1,2), dim=-1)
        global_pos_labels = timeindex.long()
        local_loss,global_loss = self.get_inner_loss(acf_values, features, global_pos_labels)

        autocon_loss = (local_loss.mean(dim=1) + global_loss) / 2.0
        return autocon_loss.mean()

    def train(self, timeidx,SA, WA,tod,dow,real_val, epoch=0):
        self.model.train()
        self.optimizer.zero_grad()
        output,wa_season,sa_season,smoother,inner_trend = self.model(SA,WA, tod,dow)
        wa_season, sa_season = wa_season.transpose(1,2),sa_season.transpose(1,2)
        q_s = F.normalize(wa_season, dim=-1)
        k_s = F.normalize(sa_season, dim=-1)
        q_s_freq = fft.rfft(q_s, dim=1)
        k_s_freq = fft.rfft(k_s, dim=1)
        q_s_amp, q_s_phase = self.convert_coeff(q_s_freq)
        k_s_amp, k_s_phase = self.convert_coeff(k_s_freq)
        outer_loss = self.outer_loss(q_s_amp, k_s_amp) + self.outer_loss(q_s_phase, k_s_phase)
        outer_loss = (self.alpha * (outer_loss / 2))
        inner_loss = 0.1 * self.inner_loss(timeidx,inner_trend)
        output = output.transpose(1, 3) # (64,1,207,12)
        real = torch.unsqueeze(real_val,dim=-1).transpose(1,3)
        predict = self.scaler.inverse_transform(output)
        loss = self.loss(predict, real, 0.0) + outer_loss + inner_loss
        loss.backward()
        if self.clip is not None:
            torch.nn.utils.clip_grad_norm_(self.model.parameters(), self.clip)
        self.optimizer.step()
        mape = util.masked_mape(predict,real,0.0).item()
        mae = util.masked_mae(predict,real,0.0).item()
        rmse = util.masked_rmse(predict,real,0.0).item()
        return mae,mape,rmse

    def eval(self, SA,WA,tod,dow, real_val):
        self.model.eval()
        output,_,_,_,_ = self.model(SA,WA,tod,dow)
        output = output.transpose(1, 3)
        real = torch.unsqueeze(real_val, dim=-1).transpose(1,3)
        predict = self.scaler.inverse_transform(output)
        mape = util.masked_mape(predict,real,0.0).item()
        mae = util.masked_mae(predict,real,0.0).item()
        rmse = util.masked_rmse(predict,real,0.0).item()
        return mae,mape,rmse
