import torch.utils.data as torch_data
import numpy as np
import torch
import pandas as pd
from util import StandardScaler

class ForecastDataset(torch_data.Dataset):
    def __init__(self, scale,df, window_size, horizon, interval=1):
        self.window_size = window_size
        self.interval = interval
        self.horizon = horizon
        self.data = df
        self.df_length = len(df)
        self.x_end_idx = self.get_x_end_idx()
        self.scaler = scale
        self.data_value = self.scaler.transform(self.data.values)
        self.input = self.__read_data__()


    def __getitem__(self, index):
        hi = self.x_end_idx[index]
        lo = hi - self.window_size
        train_data = self.input[lo: hi]
        target_data = self.data.values[hi:hi + self.horizon]
        x = torch.from_numpy(train_data).type(torch.float)
        y = torch.from_numpy(target_data).type(torch.float)
        return index, x, y

    def __len__(self):
        return len(self.x_end_idx)

    def get_x_end_idx(self):
        # each element `hi` in `x_index_set` is an upper bound for get training data
        # training data range: [lo, hi), lo = hi - window_size
        x_index_set = range(self.window_size, self.df_length - self.horizon + 1)
        x_end_idx = [x_index_set[j * self.interval] for j in range((len(x_index_set)) // self.interval)]
        return x_end_idx


    def __read_data__(self):
        num_samples, num_nodes = self.data.shape
        df_stamp = self.data.index
        df_stamp = pd.to_datetime(df_stamp,format ='%Y/%m/%d %H:%M')
        data = np.expand_dims(self.data_value, axis=-1)
        feature_list = [data]
        time_ind = (df_stamp.values - df_stamp.values.astype("datetime64[D]")) / np.timedelta64(1, "D")
        time_in_day = np.tile(time_ind, [1, num_nodes, 1]).transpose((2, 1, 0))
        feature_list.append(time_in_day)
        dow = df_stamp.dayofweek
        dow_tiled = np.tile(dow, [1, num_nodes, 1]).transpose((2, 1, 0))
        feature_list.append(dow_tiled)
        data = np.concatenate(feature_list, axis=-1)
        return data

